from binance.client import Client
from bot.logging_config import setup_logger

logger = setup_logger()

class BinanceFuturesClient:
    BASE_URL = "https://testnet.binancefuture.com"

    def __init__(self, api_key, api_secret):
        self.client = Client(api_key, api_secret)
        self.client.FUTURES_URL = self.BASE_URL

    def place_order(self, **kwargs):
        logger.info(f"Order request: {kwargs}")
        return self.client.futures_create_order(**kwargs)
