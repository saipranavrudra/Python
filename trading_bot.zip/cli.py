import argparse
import os
from dotenv import load_dotenv
from bot.client import BinanceFuturesClient
from bot.orders import create_order_payload

load_dotenv()

def main():
    parser = argparse.ArgumentParser(description="Binance Futures Testnet Trading Bot")
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--side", required=True, choices=["BUY", "SELL"])
    parser.add_argument("--type", required=True, choices=["MARKET", "LIMIT"])
    parser.add_argument("--quantity", type=float, required=True)
    parser.add_argument("--price", type=float)

    args = parser.parse_args()

    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")

    client = BinanceFuturesClient(api_key, api_secret)

    payload = create_order_payload(
        args.symbol, args.side, args.type, args.quantity, args.price
    )

    response = client.place_order(**payload)
    print(response)

if __name__ == "__main__":
    main()
